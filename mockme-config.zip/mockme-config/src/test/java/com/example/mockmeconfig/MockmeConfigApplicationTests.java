package com.example.mockmeconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockmeConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
